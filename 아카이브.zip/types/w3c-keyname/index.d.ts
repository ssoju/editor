declare module 'w3c-keyname' {
  import * as Keyname from 'w3c-keyname';
  export function keyName(event: KeyboardEvent): string;
}
