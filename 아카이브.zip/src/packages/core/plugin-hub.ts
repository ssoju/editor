import { EditorState, Plugin, PluginKey, Transaction } from 'prosemirror-state';
import { Decoration, DecorationSet, EditorView } from 'prosemirror-view';
import { keydownHandler } from 'prosemirror-keymap';
import { Slice } from 'prosemirror-model';
import { delay, isArray, flatten, forEach, memoize } from 'lodash';
import debugFactory from 'debug';

import { generateKeyName, isPureKey } from '~/packages/lib/keyboard';
import CallbackManager from '~/packages/lib/callback-manager';
import pluginList from '~/packages/plugins';
import Editor from '~/packages/core/editor';
import EditorPlugin from './plugin';

const pluginKey = new PluginKey('plugin-hub');

const debug = debugFactory('editor:plugin-hub');

export default class PluginHub {
  key = pluginKey;
  editor: Editor;
  plugins: EditorPlugin[] = [];
  actions: CallbackManager = new CallbackManager();
  filters: CallbackManager = new CallbackManager();
  hotkeys: Record<string, any> = {};
  props: Record<string, any> = this.getProps();
  state: Record<string, any>;
  composingText: string[] = [];
  composingStart: number = 0;
  compositionEndTime: number = 0;
  composing: boolean = false;
  pmPlugin: Plugin | null = null;

  constructor(editor: Editor) {
    this.editor = editor;
    this.getIterator = memoize(this.getIterator);
    this.state = {
      init: this.getIterator('handleStateInit'),
      apply: this.getIterator('handleStateApply'),
    };
  }

  /**
   * ProseMirror의 Plugin 형태로 감싼다.
   */
  asProseMirrorPlugin() {
    if (!this.pmPlugin) {
      // @ts-ignore
      this.pmPlugin = new Plugin(this);
    }
    return this.pmPlugin;
  }

  /**
   * 등록된 플러그인에서 전달한 메소드 이름을 훑어가며 실행하는 이터레이터 함수를 반환한다.
   * @param {String} methodName 등록된 플러그인에서 호출할 메소드 이름
   * @param {any} until 해당 값이 반환되면 실행을 멈춘다.
   * @return {Function} 이터레이터
   * @private
   */
  getIterator = (methodName: string, until: any = {}) => {
    return (...args: any[]) => {
      return !!this.plugins.find((plugin) => {
        // @ts-ignore
        return until === plugin[methodName]?.(...args);
      });
    };
  };

  /**
   * @private
   */
  registerPlugins = () => {
    try {
      this.plugins = Object.values(pluginList)
        .filter(Boolean)
        .map((pluginClass: any) => {
          const plugin = new pluginClass(this.editor);

          return plugin;
        });
    } catch (e) {
      debug('Failed to register plugins', e);
    }
  };

  /**
   * 단축키를 등록한다.
   * @param {String} keyName
   * @param {Function} callback
   * @param {int} priority 우선 순위. 숫자가 작을 수록 먼저 실행된다.
   */
  registerHotkey = (keyName: string, callback: any, priority = 10) => {
    if (!this.hotkeys[keyName]) {
      this.hotkeys[keyName] = [];
    }
    if (!this.hotkeys[keyName][priority]) {
      this.hotkeys[keyName][priority] = [];
    }
    this.hotkeys[keyName][priority].push(keydownHandler({ [keyName]: callback }));
  };

  view = (view: EditorView) => {
    // 뷰가 초기화 될 때 플러그인을 실행한다.
    if (!this.plugins.length) {
      this.registerPlugins();
    }

    debug('view init');

    this.getIterator('handleViewInit')(view);
    this.editor.emit('view-init', view);

    return {
      update: this.getIterator('handleViewUpdate'),
      destroy: this.handleViewDestroy.bind(this, view),
    };
  };

  getProps() {
    // ProseMirror에서 핸들러 형태로 지원하는 이벤트 목록
    // 참고: http://prosemirror.net/docs/ref/#view.EditorProps
    const handlers: Record<string, any> = {};

    [
      'handleKeyPress',
      'handleClick',
      'handleClickOn',
      'handleDoubleClick',
      'handleDoubleClickOn',
      'handleTripleClick',
      'handleTripleClickOn',
      'handlePaste',
      'handleDrop',
      'handleScrollToSelection',
      'createSelectionBetween',
    ].forEach((name) => (handlers[name] = this.getIterator(name, true)));

    return {
      decorations: this.decorations,
      handleKeyDown: this.handleKeyDown,
      handleTextInput: this.handleTextInput,
      handleDOMEvents: {
        mousedown: this.getIterator('handleMouseDown', true),
        mousemove: this.getIterator('handleMouseMove'),
        mouseleave: this.getIterator('handleMouseLeave'),
        /* CJK와 같이 조합이 필요한 언어를 위한 처리 */
        compositionstart: this.handleCompositionStart,
        compositionupdate: this.handleCompositionUpdate,
        compositionend: this.handleCompositionEnd,
        keyup: this.handleKeyUp,
        blur: this.getIterator('handleBlur'),
        focus: this.getIterator('handleFocus'),
        nodeviewblur: this.getIterator('handleNodeViewBlur'),
      },
      transformPastedHTML: this.transformPastedHTML,
      transformPastedText: this.transformPastedText,
      transformPasted: this.transformPasted,
      ...handlers,
    };
  }

  /**
   * 한국어, 일본어 등 문자 조합과 관련된 동작을 처리한다.
   * @param {EditorView} view
   * @param {dom.KeyboardEvent} event
   */
  preprocessKeyDown = (view: EditorView, event: KeyboardEvent) => {
    const keyName = generateKeyName(event);

    // 엔터만 다룬다.
    if (keyName !== 'Enter') return false;

    // 문자 조합이 끝난 직후만 다룬다.
    if (Date.now() - this.compositionEndTime > 5) return false;

    // 일정한 시간을 두고 지연시킨 후 이벤트를 다시 발생시킨다.
    const keyEvent = new KeyboardEvent('keydown', { key: event.key, code: event.code });
    // @ts-ignore
    delay(() => event.target.dispatchEvent(keyEvent), 5);

    return true;
  };

  /**
   * @param {EditorView} view
   * @param {dom.KeyboardEvent} event
   */
  handleKeyDown = (view: EditorView, event: KeyboardEvent) => {
    if (this.preprocessKeyDown(view, event)) {
      return true;
    }

    this.editor.emit('keydown', event);

    // 단축키 처리
    const hotkeys = this.hotkeys[generateKeyName(event)];
    if (hotkeys) {
      const handled = flatten(hotkeys)
        .filter(Boolean)
        .some((hotkey: any) => hotkey(view, event) === true);

      if (handled) {
        event.stopPropagation();
        return true;
      }
    }

    return this.getIterator('handleKeyDown', true)(view, event);
  };

  handleKeyUp = (view: EditorView, event: KeyboardEvent) => {
    if (isPureKey(event) && event.key === ' ' && Date.now() - this.compositionEndTime < 100) {
      // 텍스트 조합이 스페이스로 끝나서 글자+공백이 되는 케이스
      this.getIterator('handleCompositionSpaceEnd', true)(view, event);
    }
    return this.getIterator('handleKeyUp', true)(view, event);
  };

  handleTextInput = (view: EditorView, from: number, to: number, text: string) => {
    return this.getIterator('handleTextInput', true)(view, from, to, text);
  };

  /**
   * @param {EditorView} view
   * @param {dom.Event} event
   */
  handleCompositionStart = (view: EditorView, event: CompositionEvent) => {
    const from = view.state.selection.from;
    if (!this.composingText) {
      this.composingText = [];
    }
    this.composing = true;
    this.composingStart = from;
    this.composingText.push(event.data);

    return this.getIterator('handleCompositionStart', true)(view, event);
  };

  /**
   * @param {EditorView} view
   * @param {dom.Event} event
   */
  handleCompositionUpdate = (view: EditorView, event: CompositionEvent) => {
    this.composingText[this.composingText.length - 1] = event.data;

    // 시작 위치를 블럭의 시작 지점까지 확장
    const from = view.state.doc.resolve(this.composingStart).start();
    const to = this.composingStart;
    const beforeText = view.state.doc.textBetween(from, to, undefined, '\ufffc');
    const text = this.composingText.join('');

    // 그 밖의 다른 핸들러 실행
    const handled = this.getIterator('handleCompositionUpdate', true)(view, event);

    // 텍스트 컴포징 핸들러 실행
    this.handleComposingText(view, from, to, text.length, beforeText + text);

    return handled;
  };

  /**
   * @param {EditorView} view
   * @param {dom.Event} event
   */
  handleCompositionEnd = (view: EditorView, event: CompositionEvent) => {
    this.compositionEndTime = Date.now();
    this.composing = false;
    return this.getIterator('handleCompositionEnd', true)(view, event);
  };

  /**
   * @param {EditorView} view
   * @param {int} from 현재 블럭의 시작 지점
   * @param {int} to 조합 중인 텍스트 바로 앞 위치
   * @param {int} count 조합중인 텍스트의 길이
   * @param {String} text 조합중인 텍스트 및 그 앞에 있는 텍스트
   */
  handleComposingText = (view: EditorView, from: number, to: number, count: number, text: string) => {
    return this.getIterator('handleComposingText', true)(view, from, to, count, text);
  };

  /**
   * 재생성을 위해 뷰가 파괴되기 직전에 실행된다.
   * @param {EditorView} view
   */
  handleViewDestroy(view: EditorView) {
    debug('view destroy');

    this.getIterator('handleViewDestroy')(view);
    this.editor.emit('view-destroy', view);
  }

  /**
   * 텍스트를 조합 중인지 여부를 반환한다.
   * @return {bool} 조합 중이면 true, 아니면 false
   */
  isComposingText = () => {
    return this.composing;
  };

  /**
   * 플러그인에서 등록한 명령어의 목록을 반환한다.
   * @return {Object} 등록된 명령어 목록
   */
  getActions() {
    const names = this.actions.getNames();
    return names.reduce((actionList: Record<string, any>, name) => {
      actionList[name] = (...args: any[]) => this.editor.exec(name, ...args);
      return actionList;
    }, {});
  }

  /**
   * 노드뷰 커스텀 렌더러의 목록을 반혼한다.
   * @return {Object} 등록된 커스텀 렌더러 목록
   */
  getNodeViews() {
    return Object.keys(pluginList).reduce((nodeViews, pluginName) => {
      const pluginClass = pluginList[pluginName];
      const localViews = (pluginClass && pluginClass.nodeViews()) || {};

      return { ...nodeViews, ...localViews };
    }, {});
  }

  /**
   * 노드를 꾸밀 데코레이터 세트를 반환한다.
   * @param {EditorState} state
   * @return {DecorationSet}
   * @see http://prosemirror.net/docs/ref/#view.EditorProps.decorations
   */
  decorations = (state: EditorState) => {
    let decorations = this.plugins.reduce((decos, plugin) => {
      const deco = plugin.decorations(state);
      if (isArray(deco)) decos = decos.concat(deco);
      return decos;
    }, [] as Decoration[]);

    decorations = decorations.filter((deco) => deco instanceof Decoration);

    return DecorationSet.create(state.doc, decorations);
  };

  /**
   * @param {Transaction[]} trs
   * @param {EditorState} prev 변경 전의 상태
   * @param {EditorState} next 변경 후의 상태
   * @see http://prosemirror.net/docs/ref/#state.PluginSpec.appendTransaction
   */
  appendTransaction = (trs: Transaction[], prev: EditorState, next: EditorState) => {};

  /**
   * @param {Transaction} tr 에디터 트랜잭션
   * @see http://prosemirror.net/docs/ref/#state.PluginSpec.filterTransaction
   */
  filterTransaction = (tr: Transaction, state: EditorState) => {
    if (tr.getMeta('@handled')) return true;

    tr.setMeta('@handled', true);

    // // 다른 플러그인의 filterTransaction 처리
    let disallowed = this.getIterator('filterTransaction', false)(tr);

    if (disallowed) return false;

    this.editor.emit('transaction', tr);

    return true;
  };

  transformPastedHTML = (originalHTML: string) => {
    return this.plugins.reduce((html, plugin) => {
      return plugin.transformPastedHTML?.(html) || html;
    }, originalHTML);
  };

  transformPastedText = (originalText: string) => {
    return this.plugins.reduce((text, plugin) => {
      return plugin.transformPastedText?.(text) || text;
    }, originalText);
  };

  transformPasted = (originalSlice: Slice) => {
    return this.plugins.reduce((slice, plugin) => {
      return plugin.transformPasted?.(slice) || slice;
    }, originalSlice);
  };
}
