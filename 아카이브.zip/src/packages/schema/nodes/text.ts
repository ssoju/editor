import { NodeSpec } from 'prosemirror-model'

export const text: NodeSpec = {
  group: 'inline',
}
