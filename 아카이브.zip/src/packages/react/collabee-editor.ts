


export default class CollabeeEditor() {

}
