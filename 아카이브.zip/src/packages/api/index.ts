import document from './document';
import history from './history';

export default {
  document,
  history,
};
