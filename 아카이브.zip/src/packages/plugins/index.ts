import Box from './box';

export default {
  box: Box
} as Record<string, any>
