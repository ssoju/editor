https://github.com/hubgit/react-prosemirror/blob/e0fafeaeb3166b776722bfd751728973d80affd1/demo/App.tsx#L39
